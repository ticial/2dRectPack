export type Size = { width: number; height: number };
export type RectCoord = { top: number; left: number; right: number; bottom: number; initialOrder: number };
export type PackDirection = "none" | "left" | "top";
